import math, random

def q_square():
    a = random.randint(1, 10)
    return f"Enter the square of {a}", a ** 2

def q_remainder():
    c, d = random.randint(10, 100), random.randint(1, 10)
    return f"What is the remainder when {c} is divided by {d}?", c % d

def q_factorial():
    f = random.randint(1, 6)
    return f"What is the factorial of {f}?", math.factorial(f)

def q_exponent():
    h, j = random.randint(1, 7), random.randint(0, 3)
    return f"What is {h}^{j}?", h ** j

def q_equation():
    m, n, p = random.randint(1, 10), random.randint(0, 10), random.randint(1, 10)
    return f"Calculate: ({m} x {n}) + {p}", m * n + p

QUESTIONS = [q_square, q_remainder, q_factorial, q_exponent, q_equation]

def new_question(i):
    text, answer = QUESTIONS[i]()
    return {"text": text, "answer": answer}

def comment(score):
    if score >= 4:
        return "Well Done!"
    return "Good Attempt!" if score >= 2 else "Practice some more"